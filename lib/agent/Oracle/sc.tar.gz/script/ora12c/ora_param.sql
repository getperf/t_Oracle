select name ,value 
from v$parameter
;
